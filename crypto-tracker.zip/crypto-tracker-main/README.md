# Cryptocurrency Tracker made with React 👋

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Description
A React.js application that displays price, volume, and other information about the top 100 most popular cryptocurrencies on coingecko.com

![Screenshot](Capture.PNG)
https://riz1-lv.github.io/crypto-tracker/
